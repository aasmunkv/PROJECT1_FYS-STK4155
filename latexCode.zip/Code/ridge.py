def ridge(X, z, l):
    I = np.identity(X.shape[1])
    H = np.linalg.pinv(X.T@X + l*I)
    beta = H@(X.T@z)
    return beta