def CreateDesignMatrix(x, y, pol_deg = 5):
	if len(x.shape) > 1:
		x, y = np.ravel(x), np.ravel(y)
	N, l = len(x), int((pol_deg+1)*(pol_deg+2)/2)
	X = np.ones((N, l))
	for i in range(1,pol_deg+1):
		q = int((i)*(i+1)/2)
		for k in range(i+1):
			X[:,q+k] = x**(i-k) * y**k
	return X

def FrankeFunction(x, y):
    term1 = 0.75*np.exp(-(0.25*(9*x-2)**2) - 0.25*((9*y-2)**2))
    term2 = 0.75*np.exp(-((9*x+1)**2)/49.0 - 0.1*(9*y+1))
    term3 = 0.5*np.exp(-(9*x-7)**2/4.0 - 0.25*((9*y-3)**2))
    term4 = -0.2*np.exp(-(9*x-4)**2 - (9*y-7)**2)
    return term1 + term2 + term3 + term4
    
def MSE(z, z_hat):
	if (len(z.shape) > 1):
		z = np.ravel(z)
	if (len(z_hat.shape)) > 1:
		z_hat= np.ravel(z_hat)
	SYY = (z-z_hat)@(z-z_hat)
	return SYY/len(z)

def r2_score(z, z_hat):
	if (len(z.shape) > 1):
			z = np.ravel(z)
	if (len(z_hat.shape)) > 1:
		z_hat = np.ravel(z_hat)
	n = len(z)
	en = (z-z_hat)@(z-z_hat)
	mean = np.sum(z)/n
	sst = (z - mean)@(z - mean)
	return 1-(en/sst)