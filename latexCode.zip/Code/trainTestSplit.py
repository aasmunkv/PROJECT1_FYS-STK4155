def train_test(x, y, model, noise_deg, pol_deg, num_points, lamb=0):
	x, y = np.meshgrid(x, y)
	x, y = np.ravel(x), np.ravel(y)
	z = FrankeFunction(x,y) + noise_deg*np.random.randn(len(x))
	X = CreateDesignMatrix(x, y, pol_deg)
	X_train,X_test,z_train,z_test=train_test_split(X,z,test_size=0.36)
	beta = model(X_train, z_train, lamb)
	z_pred = X_test@beta
	return z, z_pred
