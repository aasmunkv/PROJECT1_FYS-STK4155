def k_fold_CV(k, model, x, y, num, pol_deg, lamb, noise_deg = 0):
	ind =  np.array(range(num**2))
	np.random.shuffle(ind)
	fold_size = int((num**2)/k)
	x_train, y_train = [np.zeros((k-1)*fold_size) for i in range(2)]
	x_test, y_test = [np.zeros(fold_size) for i in range(2)]
	mse_arr, r2_arr, bias_arr, s_arr = [np.zeros(k) for i in range(4)]
	beta_arr = np.empty((k, int((pol_deg+1)*(pol_deg+2)/2)))
	train_noise = noise_deg*np.random.randn(len(x_train))
    test_noise = noise_deg*np.random.randn(len(x_test))
	for i in range(k):
		ind1, ind2 = ind[:fold_size*i], ind[fold_size*(i+1):]
		train_ind = np.array(list(ind1)+list(ind2))
		for j in range(len(train_ind)):
			x_train[j], y_train[j] = x[train_ind[j]], y[train_ind[j]]
		X_train = CreateDesignMatrix(x_train, y_train, pol_deg)
		z_train = FrankeFunction(x_train, y_train) + train_noise
			
		test_ind = ind[fold_size*i: fold_size*(i+1)]
		for l in range(len(test_ind)):
			x_test[l], y_test[l] = x[test_ind[l]], y[test_ind[l]]
		X_test = CreateDesignMatrix(x_test, y_test, pol_deg)
		z_test = FrankeFunction(x_test, y_test) + test_noise
		beta = model(X_train, z_train, lamb)
		z_pred = X_test@beta
		mse_arr[i] = MSE(z_pred, z_test)
		r2_arr[i] = r2_score(z_pred, z_test)
		s_arr[i] = np.mean((z_pred - np.mean(z_pred))**2)
		bias_arr[i] = np.mean(z_test-np.mean(z_pred))
	r2,mse,bias,s = [sum(i)/k for i in [r2_arr,mse_arr,bias_arr,s_arr]]
	return (r2, mse, s, bias)