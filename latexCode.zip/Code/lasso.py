def lasso(X, z, l):
	clf = linear_model.Lasso(alpha=l, fit_intercept=False)
	clf.fit(X, z)
	beta = clf.coef_
	return beta