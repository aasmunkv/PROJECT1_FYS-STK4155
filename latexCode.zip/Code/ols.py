def ols(X, z):
	H = np.linalg.pinv(X.T@X)
	beta = H@(X.T@z)
	return beta